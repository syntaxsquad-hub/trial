from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlmodel import Session
from datetime import datetime
from ..db import get_session
from ..models import SensorReading, CrowdReport, Alert
from ..services.predictor import compute_risk, estimate_lead_time
from ..services.localization import translate

router = APIRouter(prefix="/ingest", tags=["ingest"])

class SensorIn(BaseModel):
    timestamp: datetime
    lat: float
    lon: float
    wave_height_m: float = 0.0
    sea_level_m: float = 0.0
    wind_kts: float = 0.0
    rainfall_mm_h: float = 0.0
    temperature_c: float = 0.0
    salinity_psu: float = 0.0
    language: str = "en"

class CrowdIn(BaseModel):
    timestamp: datetime
    lat: float
    lon: float
    people_count: int
    note: str = ""

@router.post("/sensor")
def ingest_sensor(data: SensorIn, session: Session = Depends(get_session)):
    reading = SensorReading(**data.model_dump(exclude={"language"}), source="sensor")
    session.add(reading)
    # Predict & possibly create alert
    level, score, why = compute_risk(data.model_dump())
    title = f"Risk score {score:.2f}"
    message = f"Indicators: {why}"
    title_t, message_t = translate(level, title, message, data.language)

    from ..models import Alert
    alert = Alert(level=level, title=title_t, message=message_t, lat=data.lat, lon=data.lon, category="storm")
    session.add(alert)
    session.commit()
    session.refresh(alert)
    return {"ok": True, "id": reading.id, "alert": alert}

@router.post("/crowd")
def ingest_crowd(data: CrowdIn, session: Session = Depends(get_session)):
    rep = CrowdReport(**data.model_dump())
    session.add(rep)
    level, score, why = compute_risk({"people_count": data.people_count})
    title = f"Crowd risk {score:.2f}"
    message = f"Indicators: {why}"
    alert = Alert(level=level, title=title, message=message, lat=data.lat, lon=data.lon, category="crowd")
    session.add(alert)
    session.commit()
    return {"ok": True}