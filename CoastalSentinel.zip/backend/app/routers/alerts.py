from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from ..db import get_session
from ..models import Alert
from typing import List

router = APIRouter(prefix="/alerts", tags=["alerts"])

@router.get("/", response_model=List[Alert])
def list_alerts(limit: int = 50, session: Session = Depends(get_session)):
    return session.exec(select(Alert).order_by(Alert.created_at.desc()).limit(limit)).all()