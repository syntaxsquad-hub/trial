from fastapi import APIRouter
from ..services.evacuation import get_routes_geojson

router = APIRouter(tags=["system"])

@router.get("/health")
def health():
    return {"status": "ok"}

@router.get("/evac/routes")
def evac_routes():
    return get_routes_geojson()