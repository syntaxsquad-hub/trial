from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime

class SensorReading(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    timestamp: datetime = Field(index=True)
    lat: float
    lon: float
    wave_height_m: float = 0.0
    sea_level_m: float = 0.0
    wind_kts: float = 0.0
    rainfall_mm_h: float = 0.0
    temperature_c: float = 0.0
    salinity_psu: float = 0.0
    source: str = "sensor"

class CrowdReport(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    timestamp: datetime = Field(index=True)
    lat: float
    lon: float
    people_count: int = 0
    note: str = ""

class Alert(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=datetime.utcnow, index=True)
    level: str  # info | watch | warning | danger
    title: str
    message: str
    lat: Optional[float] = None
    lon: Optional[float] = None
    expires_at: Optional[datetime] = None
    language: str = "en"
    category: str = "general"  # storm, surge, bloom, pollution, crowd, erosion