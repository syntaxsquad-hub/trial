from pydantic import BaseModel
from typing import List
import os

class Settings(BaseModel):
    SECRET_KEY: str = os.getenv("SECRET_KEY", "dev")
    ALGORITHM: str = os.getenv("ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440"))
    CORS_ORIGINS: List[str] = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
    STORM_SURGE_M: float = float(os.getenv("STORM_SURGE_M", "1.5"))
    WAVE_HEIGHT_M: float = float(os.getenv("WAVE_HEIGHT_M", "3.0"))
    RAINFALL_MM_H: float = float(os.getenv("RAINFALL_MM_H", "60"))
    WIND_KTS: float = float(os.getenv("WIND_KTS", "35"))
    ALERT_TICK: int = int(os.getenv("ALERT_TICK", "10"))

settings = Settings()