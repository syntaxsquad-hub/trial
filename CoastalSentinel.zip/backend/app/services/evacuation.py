import json
from pathlib import Path

ROUTES_PATH = Path(__file__).resolve().parent.parent / "static" / "evac_routes.geojson"

def get_routes_geojson():
    if ROUTES_PATH.exists():
        return json.loads(ROUTES_PATH.read_text(encoding="utf-8"))
    return {"type":"FeatureCollection","features":[]}