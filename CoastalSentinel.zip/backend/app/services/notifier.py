from typing import Dict, Any

# Stubs you can connect to SMS/Email/FCM vendors
def send_sms(to_number: str, body: str) -> Dict[str, Any]:
    # integrate with Twilio or local gateway here
    return {"status": "queued", "to": to_number, "body": body}

def send_push(token: str, title: str, body: str) -> Dict[str, Any]:
    return {"status": "queued", "token": token, "title": title, "body": body}