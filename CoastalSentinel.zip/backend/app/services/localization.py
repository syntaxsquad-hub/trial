def translate(level: str, title: str, message: str, language: str = "en"):
    if language == "hi":
        tmap = {
            "info": "सामान्य स्थिति",
            "watch": "सतर्कता",
            "warning": "चेतावनी",
            "danger": "गंभीर चेतावनी"
        }
        title_hi = tmap.get(level, "अद्यतन") + ": " + title
        # Simple pass-through message for demo; plug in ICU messages or i18n keys in production
        return title_hi, message
    return title, message