from datetime import datetime, timedelta
from typing import Dict, Any, Tuple
from ..core.config import settings

# Simple, explainable thresholds -> risk levels
def compute_risk(features: Dict[str, float]) -> Tuple[str, float, str]:
    score = 0.0
    reasons = []

    if features.get("sea_level_m", 0) >= settings.STORM_SURGE_M:
        score += 0.4
        reasons.append(f"Sea level ≥ {settings.STORM_SURGE_M} m")
    if features.get("wave_height_m", 0) >= settings.WAVE_HEIGHT_M:
        score += 0.3
        reasons.append(f"Wave height ≥ {settings.WAVE_HEIGHT_M} m")
    if features.get("rainfall_mm_h", 0) >= settings.RAINFALL_MM_H:
        score += 0.2
        reasons.append(f"Rainfall ≥ {settings.RAINFALL_MM_H} mm/h")
    if features.get("wind_kts", 0) >= settings.WIND_KTS:
        score += 0.2
        reasons.append(f"Wind ≥ {settings.WIND_KTS} kts")

    crowd = features.get("people_count", 0)
    if crowd >= 200:
        score += 0.2
        reasons.append("High crowd density")

    level = "info"
    if score >= 0.8:
        level = "danger"
    elif score >= 0.6:
        level = "warning"
    elif score >= 0.3:
        level = "watch"

    title = {
        "info": "Coastal status: Normal",
        "watch": "Heads up: Conditions worsening",
        "warning": "Warning: Hazardous conditions likely",
        "danger": "DANGER: Immediate coastal threat"
    }[level]

    return level, score, "; ".join(reasons) if reasons else "No concerning indicators"

def estimate_lead_time(hours_if_possible: float = 6.0) -> datetime:
    return datetime.utcnow() + timedelta(hours=hours_if_possible)