import asyncio
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from .core.config import settings
from .db import init_db, get_session
from .models import Alert
from sqlmodel import Session, select
from datetime import datetime, timedelta

from .routers import alerts as alerts_router
from .routers import sensors as sensors_router
from .routers import system as system_router

app = FastAPI(title="Coastal Sentinel API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(alerts_router.router)
app.include_router(sensors_router.router)
app.include_router(system_router.router)

@app.on_event("startup")
def on_startup():
    init_db()

# Simple in-memory set of connections
connections = set()

@app.websocket("/ws/alerts")
async def alerts_ws(ws: WebSocket):
    await ws.accept()
    connections.add(ws)
    try:
        # On connect, push last 5 alerts
        from .db import engine
        with Session(engine) as session:
            recent = session.exec(select(Alert).order_by(Alert.created_at.desc()).limit(5)).all()
            for a in reversed(recent):
                await ws.send_json({"type":"alert","payload": a.model_dump()})
        # Heartbeat / broadcast loop
        while True:
            await asyncio.sleep(settings.ALERT_TICK)
            # demo: send a heartbeat so clients know we're alive
            await ws.send_json({"type":"heartbeat","ts": datetime.utcnow().isoformat()})
    except WebSocketDisconnect:
        pass
    finally:
        connections.discard(ws)