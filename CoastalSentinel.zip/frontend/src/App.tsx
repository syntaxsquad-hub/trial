import { useEffect, useRef, useState } from 'react'
import maplibregl from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'
import { useTranslation } from 'react-i18next'
import AlertList from './components/AlertList'
import LanguageSwitcher from './components/LanguageSwitcher'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'
const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8000/ws/alerts'

export default function App() {
  const { t } = useTranslation()
  const mapRef = useRef<maplibregl.Map|null>(null)
  const mapContainer = useRef<HTMLDivElement|null>(null)
  const [wsStatus, setWsStatus] = useState<'connected'|'disconnected'>('disconnected')
  const [alerts, setAlerts] = useState<any[]>([])

  useEffect(() => {
    if (!mapContainer.current) return
    const map = new maplibregl.Map({
      container: mapContainer.current,
      style: 'https://demotiles.maplibre.org/style.json',
      center: [72.85, 18.95],
      zoom: 10
    })
    map.addControl(new maplibregl.NavigationControl(), 'top-right')
    map.on('load', async () => {
      const res = await fetch(API_BASE + '/evac/routes')
      const gj = await res.json()
      map.addSource('evac', { type: 'geojson', data: gj })
      map.addLayer({ id: 'evac-lines', type: 'line', source: 'evac', paint: { 'line-width': 3 } })
      map.addLayer({ id: 'evac-points', type: 'circle', source: 'evac', paint: { 'circle-radius': 6 } })
    })
    mapRef.current = map
    return () => map.remove()
  }, [])

  useEffect(() => {
    const ws = new WebSocket(WS_URL)
    ws.onopen = () => setWsStatus('connected')
    ws.onclose = () => setWsStatus('disconnected')
    ws.onmessage = (evt) => {
      const msg = JSON.parse(evt.data)
      if (msg.type === 'alert') {
        setAlerts(a => [msg.payload, ...a].slice(0, 50))
      }
    }
    return () => ws.close()
  }, [])

  return (
    <div className="min-h-screen grid grid-cols-3 gap-4 p-4">
      <header className="col-span-3 flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t('app_title')}</h1>
        <div className="flex items-center gap-4">
          <span className="text-sm">{wsStatus === 'connected' ? t('connected') : t('disconnected')}</span>
          <LanguageSwitcher />
        </div>
      </header>

      <section className="col-span-2 rounded-2xl shadow p-2 border">
        <div ref={mapContainer} className="w-full h-[70vh] rounded-xl overflow-hidden" />
      </section>

      <aside className="col-span-1 rounded-2xl shadow p-2 border overflow-auto h-[70vh]">
        <AlertList alerts={alerts} />
      </aside>

      <footer className="col-span-3 text-xs text-gray-500">
        API: {API_BASE} | WS: {WS_URL}
      </footer>
    </div>
  )
}