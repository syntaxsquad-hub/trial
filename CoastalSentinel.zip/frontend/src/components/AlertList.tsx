export default function AlertList({ alerts }: { alerts: any[] }) {
  return (
    <div>
      <h2 className="text-lg font-semibold mb-2">Alerts</h2>
      <ul className="space-y-2">
        {alerts.map((a, idx) => (
          <li key={a.id ?? idx} className="border rounded-lg p-2">
            <div className="text-sm font-medium">{a.title}</div>
            <div className="text-xs opacity-80">{a.message}</div>
            <div className="text-[10px] mt-1">Level: {a.level} • {a.category}</div>
          </li>
        ))}
        {alerts.length === 0 && (
          <li className="text-sm opacity-70">No alerts yet. Ingest sensor data to generate alerts.</li>
        )}
      </ul>
    </div>
  )
}