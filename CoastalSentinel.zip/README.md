# Coastal Sentinel – Coastal Threat Alert System

A full‑stack reference implementation of a coastal early‑warning and monitoring web app.
It demonstrates real‑time alerts (WebSocket), sensor ingestion, simple rule‑based predictive analytics,
multilingual UI, map‑based visualizations, evacuation routes, and a clean deployment story.

## ✨ Highlights
- **Real-time alerts** via WebSocket (6‑hour lead-time demo logic).
- **Multi-modal data**: ingest physical sensor metrics + crowdsourced reports.
- **Simple predictive engine**: rule-based risk scoring with easy extension points for ML.
- **Actionable guidance**: evacuation routes and scenario cards.
- **Multilingual UI**: English + Hindi; easy to extend.
- **Auth-ready**: token-based endpoints scaffold.
- **API-first** with FastAPI docs at `/docs`.
- **Modern frontend**: React + Vite + Tailwind + MapLibre for maps.
- **Dockerized** and ready for GitHub push.

> This is a starter you can expand with real data streams, satellite integrations, and SMS vendors.

---

## 🚀 Quickstart (no Docker)

### Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend
In a new terminal:
```bash
cd frontend
npm install
npm run dev
```
Open **http://localhost:5173**

---

## 🐳 Quickstart with Docker
```bash
docker compose up --build
```
- Frontend: http://localhost:5173
- Backend (API): http://localhost:8000
- API docs: http://localhost:8000/docs

---

## 📦 Project Structure
```
CoastalSentinel/
  backend/         FastAPI app, WebSocket, simple predictor
  frontend/        React + Vite + Tailwind + MapLibre UI
  docker-compose.yml
```

---

## 🔐 Env config
See `backend/.env.example`. Frontend uses `VITE_API_BASE` and `VITE_WS_URL` from Docker compose or your shell.

---

## 🧠 Extend the Predictor
Edit `backend/app/services/predictor.py` to plug in your ML models. The code isolates features and thresholds, so you can replace the risk scoring with trained models without touching routers.

---

## 🗺️ Maps & Tiles
MapLibre loads OpenStreetMap tiles (defaults to a public style). For production, configure your own tile server or a provider key.

---

## 🤝 License
MIT — use it freely, and please cite **Coastal Sentinel** when you showcase.